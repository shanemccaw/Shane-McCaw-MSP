Name this task: "IN FLIGHT: portal-favicon-logo-swap"

## Context

msp-portal currently uses `artifacts/msp-portal/public/favicon.svg` (a flat
navy square with white bar-chart glyph, landed in `fbc3a616`), referenced in
`artifacts/msp-portal/index.html` as:

```html
<link rel="icon" type="image/svg+xml" href="/favicon.svg" />
```

This is being replaced with the new master logo (M-ribbon + eye/cloud mark,
seven-pillar gradient) as a PNG-based icon set. Shane has approved using it
as-is at all sizes, including the small tab-icon sizes where the gradient
detail compresses.

Five image files are provided (attached to this task, place them exactly as
named):
- `favicon-16x16.png`
- `favicon-32x32.png`
- `favicon-48x48.png`
- `apple-touch-icon.png` (180x180)
- `icon-512.png` (512x512, for PWA manifest / app icon use)

## Step 1 (before any other work)

Update `PLATFORM_BUILD.md`:
`⏳ IN FLIGHT — portal-favicon-logo-swap`
Commit this alone as its own small commit.

## Task

1. Place all five provided PNGs into `artifacts/msp-portal/public/`.
2. Remove the old `artifacts/msp-portal/public/favicon.svg` (fully superseded
   — confirm no other reference to `/favicon.svg` exists anywhere in
   `artifacts/msp-portal/src` before deleting; if one exists, stop and
   report rather than deleting under it).
3. Update `artifacts/msp-portal/index.html`'s `<head>` to reference the new
   set:
   ```html
   <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png" />
   <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png" />
   <link rel="icon" type="image/png" sizes="48x48" href="/favicon-48x48.png" />
   <link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png" />
   ```
4. If a web app manifest exists for msp-portal (check for
   `manifest.json`/`manifest.webmanifest` referenced in `index.html`),
   update its `icons` array to include `icon-512.png` at `"512x512"`. If no
   manifest exists, skip this step — don't create one as a side effect of a
   favicon swap.
5. Grep the rest of the codebase (`artifacts/admin-panel`,
   `artifacts/shane-mccaw-consulting`) for any hardcoded reference to the
   old portal favicon path — report findings, don't touch other apps' icons
   in this task.

## Logging

No new logging surface needed — static asset swap only.

## Last step (after files are in place and index.html updated)

Update `PLATFORM_BUILD.md`:
`✅ DONE — portal-favicon-logo-swap` with the real commit hash.

Commit only this task's changes on its own dedicated commit.

---

**Model + effort:** Claude Code, Haiku 4.5, Low effort. Pure asset
placement and markup update, no logic changes.
